<?php
  
  if(isset($_SESSION['username'])==false) {
      
?>  
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <title>vehicle management system</title>
  
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script> 
  <script src="https://code.jquery.com/jquery-2.2.0.min.js" type="text/javascript"></script>
   <script src="https://unpkg.com/scrollreveal/dist/scrollreveal.min.js"></script>
  <link rel="stylesheet" type="text/css" href="./slick/slick.css">
  <link rel="stylesheet" type="text/css" href="./slick/slick-theme.css"> 
  <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Abril+Fatface&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <link rel="stylesheet" href="animate.css">
  <link rel="stylesheet" href="style.css">
</head> 

<style>
#myNavbar{
  font-family: 'Candara', cursive;
  font-size: 3vh;
}
</style>

<body>
       <nav class="navbar navbar-inverse navbar-fixed-top gabanav">
        <div class="container-fluid">
          <div class="navbar-header">
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
              <span class="icon-bar"></span>
              <span class="icon-bar"></span>
              <span class="icon-bar"></span>                        
            </button>
          </div>
          <div class="collapse navbar-collapse" id="myNavbar">
            <ul class="nav navbar-nav gabali">
              <li ><a href="index.php">Home</a></li>
              <li><a href="trucklist.php" class="smooth-scroll">Vehicle</a></li>
              <li><a href="driverlist.php">Driver</a></li>
              <li><a href="landing_route.php">Truck Route</a></li>
              <li><a href="ab.php">About Us</a></li>
              

            </ul>
            <ul class="nav navbar-nav navbar-right">
              <li><a href="login_admin.php"><span class="glyphicon glyphicon-log-in"></span> Login</a></li>
            </ul>
          </div> 

          </div>   
      </nav>
           
 
     
  <?php } else { ?> 

     <nav class="navbar navbar-inverse navbar-fixed-top gabanav">
        <div class="container-fluid">
          <div class="navbar-header">
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
              <span class="icon-bar"></span>
              <span class="icon-bar"></span>
              <span class="icon-bar"></span>                        
            </button>

          </div>
          <div class="collapse navbar-collapse" id="myNavbar" style="font-family: 'Candara', cursive;
          font-size: 3vh;">
            <ul class="nav navbar-nav gabali">
              <li><a href="index.php">Home</a></li>
              <li><a href="trucklist.php" class="smooth-scroll">Vehicle</a></li>
              <li><a href="driverlist.php">Driver</a></li>
              <li><a href="landing_route.php">Truck Route</a></li>
              <li><a href="ab.php">About Us</a></li>
            </ul>
            <ul class="nav navbar-nav navbar-right">
              <li><a href="logout.php"><span class="glyphicon glyphicon-user"></span> Log Out</a></li>
              <li><a href="#"><span class="glyphicon glyphicon-log-in"></span> Welcome <?php echo $_SESSION['username']; ?></a></li>
            </ul>
          </div> 

      </div> 
    
  </nav> 
  </div>
  <?php } ?> 

  

  

  
  
  
  
 
  
  